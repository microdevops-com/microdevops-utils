SELECT datname FROM pg_database;
